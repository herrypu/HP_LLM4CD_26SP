module top_module (
    input clk,
    input resetn,
    input [3:1] r,
    output reg [3:1] g
);

    reg [1:0] state, next_state;

    // State Encoding
    localparam A = 2'b00,
               B = 2'b01,
               C = 2'b10,
               D = 2'b11;

    // State transition
    always @(*) begin
        case (state)
            A: begin
                if (r[1]) next_state = B;
                else if (r[2]) next_state = C;
                else if (r[3]) next_state = D;
                else next_state = A;
            end
            
            B: begin
                if (r[1]) next_state = B;
                else next_state = A;
            end
            
            C: begin
                if (r[2]) next_state = C;
                else next_state = A;
            end
            
            D: begin
                next_state = A; // Transition back to A from D
            end
            
            default: next_state = A; // Default case
        endcase
    end

    // State Flip-Flops
    always @(posedge clk or negedge resetn) begin
        if (!resetn)
            state <= A; // Reset to state A
        else
            state <= next_state;
    end

    // Output logic
    always @(*) begin
        g = 3'b000; // Default no grant
        case (state)
            A: begin
                if (r[1]) g[1] = 1;
                else if (r[2]) g[2] = 1;
                else if (r[3]) g[3] = 1;
            end
            
            B: g[1] = 1; // Grant to device 1
            
            C: g[2] = 1; // Grant to device 2
            
            D: g[3] = 1; // Grant to device 3
            
            default: g = 3'b000; // Default no grant
        endcase
    end

endmodule
